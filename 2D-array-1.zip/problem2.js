let arr=[
              ["Shyam","Raju"],
              ["Babu Rao","Devi Prasad"],
              ["Kanji Bhai","Total Seth"]
         ];
console.log(arr[0].length);
console.log(arr[1].length);
console.log(arr[2].length);