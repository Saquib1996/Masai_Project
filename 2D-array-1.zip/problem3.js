// No of rows and column

let arr=[
  [1,2,3,4],
  [5,6,7,8],
  [9,10,11,12]
];
let rows=arr.length;
let column=arr[0].length;
console.log(rows,column);