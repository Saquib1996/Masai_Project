let items=[
              ["Shyam","Raju"],
              ["Babu Rao","Devi Prasad"],
              ["Kanji Bhai","Total Seth"]
         ];
console.log(items[0][0]);
console.log(items[0][1]);
console.log(items[1][0]);
console.log(items[1][1]);
console.log(items[2][0]);
console.log(items[2][1]);